=== Easy Child Theme Creator ===
Contributors: wpashokg 
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=RTAAFGGL53DMG
Tags: themes, child themes
Requires at least: 3.3.1
Tested up to: 4.2.2 
Stable tag: 1.2
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html


Allow people to create a child theme with best practices

== Description ==
Hello Friends,<br>
This is a wordpress plugin which will enable the admin to create a child theme for a selected parent theme.

Features:

    One click Creation of child theme.
    Configure Theme Name.
    Configure Author etc.,

== Installation ==
	
 * Upload the plugin files to the '/wp-content/plugins/' directory
 * Activate the plugin through the 'Plugins' menu in WordPress
 
== Frequently Asked Questions ==

= Do I need to change the directory permissions to make this work perfect ? =

Yes there should be proper directory permissions for this plugin to work perfect.

= Does this plugin supports language options ? =

No this plugin works only in English. Planning to support multilingual feature.

= How do I access the Created Child Theme ? =

You can access it from the Admin --> Appearance --> Your Child Theme.

= What all files are being generated with this theme Generator ? = 

Our code generates just style.css (With specified Options), functions.php (with style import from the parent theme.), screenshot.png. These theme files can be modified using editor or ftp. 

== Changelog ==
  
= 1.0 =
First Release

= 1.1 = 
Fixed form validations, now it supports multiple child theme creation.

= 1.2 =
Omit the above version it has some bugs. Fixed in the current version. Sorry for the trouble.

== Screenshots ==
1.  Easy Child Theme Creator - Admin Menu
2.  Easy Child Theme Creator - Options
